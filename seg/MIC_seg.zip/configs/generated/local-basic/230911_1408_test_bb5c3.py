_base_ = '../../mic/Med_semi_supervised.py'
name = '230911_1408_test_bb5c3'
work_dir = 'work_dirs/local-basic/230911_1408_test_bb5c3'
git_rev = ''
