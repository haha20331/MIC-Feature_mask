_base_ = '../../mic/Med_semi_supervised.py'
name = '230901_1429_test_b39de'
work_dir = 'work_dirs/local-basic/230901_1429_test_b39de'
git_rev = ''
