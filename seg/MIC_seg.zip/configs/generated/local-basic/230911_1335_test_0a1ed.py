_base_ = '../../mic/Med_semi_supervised.py'
name = '230911_1335_test_0a1ed'
work_dir = 'work_dirs/local-basic/230911_1335_test_0a1ed'
git_rev = ''
