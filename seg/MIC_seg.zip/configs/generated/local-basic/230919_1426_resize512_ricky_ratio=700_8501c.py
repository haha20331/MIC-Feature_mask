_base_ = '../../mic/Med_semi_supervised.py'
name = '230919_1426_resize512_ricky_ratio=700_8501c'
work_dir = 'work_dirs/local-basic/230919_1426_resize512_ricky_ratio=700_8501c'
git_rev = ''
