_base_ = '../../mic/Med_semi_supervised_test.py'
name = '230903_1309_test_dd9a4'
work_dir = 'work_dirs/local-basic/230903_1309_test_dd9a4'
git_rev = ''
