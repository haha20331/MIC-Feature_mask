_base_ = '../../mic/Med_semi_supervised.py'
name = '230912_1827_test_66288'
work_dir = 'work_dirs/local-basic/230912_1827_test_66288'
git_rev = ''
