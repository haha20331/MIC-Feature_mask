_base_ = '../../mic/Med_semi_supervised.py'
name = '230915_1959_PatchMask_bill_ratio=0000_19a88'
work_dir = 'work_dirs/local-basic/230915_1959_PatchMask_bill_ratio=0000_19a88'
git_rev = ''
