_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230722_1509_gtaHR2csHR_mic_hrda_s2_4efed'
work_dir = 'work_dirs/local-basic/230722_1509_gtaHR2csHR_mic_hrda_s2_4efed'
git_rev = ''
