_base_ = '../../mic/Med_semi_supervised_test.py'
name = '230902_1408_test_1ceae'
work_dir = 'work_dirs/local-basic/230902_1408_test_1ceae'
git_rev = ''
