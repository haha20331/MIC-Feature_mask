_base_ = '../../mic/Med_semi_supervised.py'
name = '230901_1529_test_1ac53'
work_dir = 'work_dirs/local-basic/230901_1529_test_1ac53'
git_rev = ''
