_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230822_1133_CleanData_WithoutFD_tua=0.88_571d1'
work_dir = 'work_dirs/local-basic/230822_1133_CleanData_WithoutFD_tua=0.88_571d1'
git_rev = ''
