_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230720_1736_gtaHR2csHR_mic_hrda_s2_c3c52'
work_dir = 'work_dirs/local-basic/230720_1736_gtaHR2csHR_mic_hrda_s2_c3c52'
git_rev = ''
