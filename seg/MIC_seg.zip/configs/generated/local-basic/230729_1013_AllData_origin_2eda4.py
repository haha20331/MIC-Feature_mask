_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230729_1013_AllData_origin_2eda4'
work_dir = 'work_dirs/local-basic/230729_1013_AllData_origin_2eda4'
git_rev = ''
