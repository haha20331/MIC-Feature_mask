_base_ = '../../mic/Med_semi_supervised.py'
name = '230906_1656_test_4a947'
work_dir = 'work_dirs/local-basic/230906_1656_test_4a947'
git_rev = ''
