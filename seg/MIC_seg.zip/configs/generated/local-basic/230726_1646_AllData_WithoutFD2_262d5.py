_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230726_1646_AllData_WithoutFD2_262d5'
work_dir = 'work_dirs/local-basic/230726_1646_AllData_WithoutFD2_262d5'
git_rev = ''
