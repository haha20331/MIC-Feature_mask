_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230828_1428_test_b5726'
work_dir = 'work_dirs/local-basic/230828_1428_test_b5726'
git_rev = ''
