_base_ = '../../mic/Med_semi_supervised_test.py'
name = '230903_1311_test_32163'
work_dir = 'work_dirs/local-basic/230903_1311_test_32163'
git_rev = ''
