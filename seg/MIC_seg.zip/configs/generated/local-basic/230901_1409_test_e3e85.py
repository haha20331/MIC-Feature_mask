_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230901_1409_test_e3e85'
work_dir = 'work_dirs/local-basic/230901_1409_test_e3e85'
git_rev = ''
