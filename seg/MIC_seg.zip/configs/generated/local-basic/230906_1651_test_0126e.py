_base_ = '../../mic/Med_semi_supervised.py'
name = '230906_1651_test_0126e'
work_dir = 'work_dirs/local-basic/230906_1651_test_0126e'
git_rev = ''
