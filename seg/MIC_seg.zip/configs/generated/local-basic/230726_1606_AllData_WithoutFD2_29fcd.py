_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230726_1606_AllData_WithoutFD2_29fcd'
work_dir = 'work_dirs/local-basic/230726_1606_AllData_WithoutFD2_29fcd'
git_rev = ''
