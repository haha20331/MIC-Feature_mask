_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230726_1626_AllData_WithoutFD2_8bc61'
work_dir = 'work_dirs/local-basic/230726_1626_AllData_WithoutFD2_8bc61'
git_rev = ''
