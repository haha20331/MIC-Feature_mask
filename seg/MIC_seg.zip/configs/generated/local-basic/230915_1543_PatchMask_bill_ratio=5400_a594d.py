_base_ = '../../mic/Med_semi_supervised.py'
name = '230915_1543_PatchMask_bill_ratio=5400_a594d'
work_dir = 'work_dirs/local-basic/230915_1543_PatchMask_bill_ratio=5400_a594d'
git_rev = ''
