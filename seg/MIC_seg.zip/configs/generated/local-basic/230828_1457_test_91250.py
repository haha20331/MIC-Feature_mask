_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230828_1457_test_91250'
work_dir = 'work_dirs/local-basic/230828_1457_test_91250'
git_rev = ''
