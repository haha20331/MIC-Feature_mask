_base_ = '../../mic/Med_semi_supervised_test.py'
name = '230903_1306_test_9d738'
work_dir = 'work_dirs/local-basic/230903_1306_test_9d738'
git_rev = ''
