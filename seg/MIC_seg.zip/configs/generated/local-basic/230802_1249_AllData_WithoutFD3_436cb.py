_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230802_1249_AllData_WithoutFD3_436cb'
work_dir = 'work_dirs/local-basic/230802_1249_AllData_WithoutFD3_436cb'
git_rev = ''
