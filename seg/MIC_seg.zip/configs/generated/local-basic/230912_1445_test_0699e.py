_base_ = '../../mic/Med_semi_supervised.py'
name = '230912_1445_test_0699e'
work_dir = 'work_dirs/local-basic/230912_1445_test_0699e'
git_rev = ''
