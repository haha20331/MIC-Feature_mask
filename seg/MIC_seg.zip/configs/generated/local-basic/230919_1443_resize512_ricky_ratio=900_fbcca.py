_base_ = '../../mic/Med_semi_supervised.py'
name = '230919_1443_resize512_ricky_ratio=900_fbcca'
work_dir = 'work_dirs/local-basic/230919_1443_resize512_ricky_ratio=900_fbcca'
git_rev = ''
