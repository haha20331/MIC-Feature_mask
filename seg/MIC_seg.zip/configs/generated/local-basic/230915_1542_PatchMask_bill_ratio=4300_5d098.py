_base_ = '../../mic/Med_semi_supervised.py'
name = '230915_1542_PatchMask_bill_ratio=4300_5d098'
work_dir = 'work_dirs/local-basic/230915_1542_PatchMask_bill_ratio=4300_5d098'
git_rev = ''
