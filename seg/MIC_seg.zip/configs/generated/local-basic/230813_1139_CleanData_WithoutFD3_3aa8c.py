_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230813_1139_CleanData_WithoutFD3_3aa8c'
work_dir = 'work_dirs/local-basic/230813_1139_CleanData_WithoutFD3_3aa8c'
git_rev = ''
