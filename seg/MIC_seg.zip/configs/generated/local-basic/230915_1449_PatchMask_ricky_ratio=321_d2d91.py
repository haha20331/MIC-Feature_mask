_base_ = '../../mic/Med_semi_supervised.py'
name = '230915_1449_PatchMask_ricky_ratio=321_d2d91'
work_dir = 'work_dirs/local-basic/230915_1449_PatchMask_ricky_ratio=321_d2d91'
git_rev = ''
