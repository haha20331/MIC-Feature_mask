_base_ = '../../mic/Med_semi_supervised_test.py'
name = '230902_1711_test_e8ba3'
work_dir = 'work_dirs/local-basic/230902_1711_test_e8ba3'
git_rev = ''
