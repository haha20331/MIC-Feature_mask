_base_ = '../../mic/Med_semi_supervised.py'
name = '230912_1333_test_356d4'
work_dir = 'work_dirs/local-basic/230912_1333_test_356d4'
git_rev = ''
