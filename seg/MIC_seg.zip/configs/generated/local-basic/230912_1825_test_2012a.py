_base_ = '../../mic/Med_semi_supervised.py'
name = '230912_1825_test_2012a'
work_dir = 'work_dirs/local-basic/230912_1825_test_2012a'
git_rev = ''
