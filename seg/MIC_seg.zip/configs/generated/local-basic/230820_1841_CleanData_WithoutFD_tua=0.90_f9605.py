_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230820_1841_CleanData_WithoutFD_tua=0.90_f9605'
work_dir = 'work_dirs/local-basic/230820_1841_CleanData_WithoutFD_tua=0.90_f9605'
git_rev = ''
