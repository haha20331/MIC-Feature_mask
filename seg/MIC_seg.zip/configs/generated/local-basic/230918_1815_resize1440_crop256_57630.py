_base_ = '../../mic/Med_semi_supervised.py'
name = '230918_1815_resize1440_crop256_57630'
work_dir = 'work_dirs/local-basic/230918_1815_resize1440_crop256_57630'
git_rev = ''
