_base_ = '../../mic/Med_semi_supervised.py'
name = '230919_1354_resize512_ricky_ratio=333_e99f7'
work_dir = 'work_dirs/local-basic/230919_1354_resize512_ricky_ratio=333_e99f7'
git_rev = ''
