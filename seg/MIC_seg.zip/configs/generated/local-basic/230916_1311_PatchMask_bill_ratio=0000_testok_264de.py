_base_ = '../../mic/Med_semi_supervised.py'
name = '230916_1311_PatchMask_bill_ratio=0000_testok_264de'
work_dir = 'work_dirs/local-basic/230916_1311_PatchMask_bill_ratio=0000_testok_264de'
git_rev = ''
