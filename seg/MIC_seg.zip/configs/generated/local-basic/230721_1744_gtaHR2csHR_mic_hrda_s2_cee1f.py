_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230721_1744_gtaHR2csHR_mic_hrda_s2_cee1f'
work_dir = 'work_dirs/local-basic/230721_1744_gtaHR2csHR_mic_hrda_s2_cee1f'
git_rev = ''
