_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230901_1411_test_8cdc9'
work_dir = 'work_dirs/local-basic/230901_1411_test_8cdc9'
git_rev = ''
