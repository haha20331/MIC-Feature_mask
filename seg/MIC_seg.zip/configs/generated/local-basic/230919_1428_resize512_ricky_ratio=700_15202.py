_base_ = '../../mic/Med_semi_supervised.py'
name = '230919_1428_resize512_ricky_ratio=700_15202'
work_dir = 'work_dirs/local-basic/230919_1428_resize512_ricky_ratio=700_15202'
git_rev = ''
