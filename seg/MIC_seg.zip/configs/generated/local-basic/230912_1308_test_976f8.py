_base_ = '../../mic/Med_semi_supervised.py'
name = '230912_1308_test_976f8'
work_dir = 'work_dirs/local-basic/230912_1308_test_976f8'
git_rev = ''
