_base_ = '../../mic/Med_semi_supervised.py'
name = '230912_1959_test_d2d30'
work_dir = 'work_dirs/local-basic/230912_1959_test_d2d30'
git_rev = ''
