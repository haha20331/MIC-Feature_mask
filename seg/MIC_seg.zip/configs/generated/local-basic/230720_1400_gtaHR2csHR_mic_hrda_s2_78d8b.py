_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230720_1400_gtaHR2csHR_mic_hrda_s2_78d8b'
work_dir = 'work_dirs/local-basic/230720_1400_gtaHR2csHR_mic_hrda_s2_78d8b'
git_rev = ''
