_base_ = '../../mic/Med_semi_supervised.py'
name = '230919_1422_resize512_ricky_ratio=700_fb2b5'
work_dir = 'work_dirs/local-basic/230919_1422_resize512_ricky_ratio=700_fb2b5'
git_rev = ''
