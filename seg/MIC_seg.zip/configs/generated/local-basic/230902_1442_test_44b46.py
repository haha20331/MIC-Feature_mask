_base_ = '../../mic/Med_semi_supervised.py'
name = '230902_1442_test_44b46'
work_dir = 'work_dirs/local-basic/230902_1442_test_44b46'
git_rev = ''
