_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230814_2316_CleanData_WithoutFD4_84904'
work_dir = 'work_dirs/local-basic/230814_2316_CleanData_WithoutFD4_84904'
git_rev = ''
