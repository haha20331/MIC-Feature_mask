_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230811_2207_CleanData_WithoutFD1_0cdd7'
work_dir = 'work_dirs/local-basic/230811_2207_CleanData_WithoutFD1_0cdd7'
git_rev = ''
