_base_ = '../../mic/Med_semi_supervised.py'
name = '230911_1415_test_b669c'
work_dir = 'work_dirs/local-basic/230911_1415_test_b669c'
git_rev = ''
