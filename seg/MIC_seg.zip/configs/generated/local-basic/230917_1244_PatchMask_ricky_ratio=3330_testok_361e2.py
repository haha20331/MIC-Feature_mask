_base_ = '../../mic/Med_semi_supervised.py'
name = '230917_1244_PatchMask_ricky_ratio=3330_testok_361e2'
work_dir = 'work_dirs/local-basic/230917_1244_PatchMask_ricky_ratio=3330_testok_361e2'
git_rev = ''
