_base_ = '../../mic/Med_semi_supervised.py'
name = '230901_1454_test_ed0f5'
work_dir = 'work_dirs/local-basic/230901_1454_test_ed0f5'
git_rev = ''
