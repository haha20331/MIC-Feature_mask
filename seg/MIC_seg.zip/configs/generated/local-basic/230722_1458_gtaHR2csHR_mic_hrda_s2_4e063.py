_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230722_1458_gtaHR2csHR_mic_hrda_s2_4e063'
work_dir = 'work_dirs/local-basic/230722_1458_gtaHR2csHR_mic_hrda_s2_4e063'
git_rev = ''
