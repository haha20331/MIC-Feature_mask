_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230704_1535_gtaHR2csHR_mic_hrda_s2_4c1f0'
work_dir = 'work_dirs/local-basic/230704_1535_gtaHR2csHR_mic_hrda_s2_4c1f0'
git_rev = ''
