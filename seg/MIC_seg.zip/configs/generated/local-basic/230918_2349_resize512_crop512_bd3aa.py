_base_ = '../../mic/Med_semi_supervised.py'
name = '230918_2349_resize512_crop512_bd3aa'
work_dir = 'work_dirs/local-basic/230918_2349_resize512_crop512_bd3aa'
git_rev = ''
