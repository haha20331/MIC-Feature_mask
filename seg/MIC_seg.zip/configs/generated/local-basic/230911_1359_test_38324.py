_base_ = '../../mic/Med_semi_supervised.py'
name = '230911_1359_test_38324'
work_dir = 'work_dirs/local-basic/230911_1359_test_38324'
git_rev = ''
