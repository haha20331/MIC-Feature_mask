_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230811_2338_CleanData_WithoutFD2_902cc'
work_dir = 'work_dirs/local-basic/230811_2338_CleanData_WithoutFD2_902cc'
git_rev = ''
