_base_ = '../../mic/Med_semi_supervised.py'
name = '230907_1336_test_1bdba'
work_dir = 'work_dirs/local-basic/230907_1336_test_1bdba'
git_rev = ''
