_base_ = '../../mic/Med_semi_supervised.py'
name = '230915_1426_PatchMask_ricky_ratio=321_40563'
work_dir = 'work_dirs/local-basic/230915_1426_PatchMask_ricky_ratio=321_40563'
git_rev = ''
