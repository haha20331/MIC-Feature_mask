_base_ = '../../mic/Med_semi_supervised.py'
name = '230906_1647_test_e680f'
work_dir = 'work_dirs/local-basic/230906_1647_test_e680f'
git_rev = ''
