_base_ = '../../mic/Med_semi_supervised.py'
name = '230915_1435_PatchMask_ricky_ratio=321_d4f5a'
work_dir = 'work_dirs/local-basic/230915_1435_PatchMask_ricky_ratio=321_d4f5a'
git_rev = ''
