_base_ = '../../mic/Med_semi_supervised.py'
name = '230907_1320_test_d2d82'
work_dir = 'work_dirs/local-basic/230907_1320_test_d2d82'
git_rev = ''
