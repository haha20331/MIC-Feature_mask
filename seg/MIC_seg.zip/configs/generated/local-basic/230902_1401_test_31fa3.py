_base_ = '../../mic/Med_semi_supervised_test.py'
name = '230902_1401_test_31fa3'
work_dir = 'work_dirs/local-basic/230902_1401_test_31fa3'
git_rev = ''
