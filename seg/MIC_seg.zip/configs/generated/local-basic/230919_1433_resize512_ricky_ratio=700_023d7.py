_base_ = '../../mic/Med_semi_supervised.py'
name = '230919_1433_resize512_ricky_ratio=700_023d7'
work_dir = 'work_dirs/local-basic/230919_1433_resize512_ricky_ratio=700_023d7'
git_rev = ''
