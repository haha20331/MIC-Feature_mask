_base_ = '../../mic/Med_semi_supervised_test.py'
name = '230902_1715_test_2b4a4'
work_dir = 'work_dirs/local-basic/230902_1715_test_2b4a4'
git_rev = ''
