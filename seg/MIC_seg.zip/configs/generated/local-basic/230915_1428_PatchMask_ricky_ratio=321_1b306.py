_base_ = '../../mic/Med_semi_supervised.py'
name = '230915_1428_PatchMask_ricky_ratio=321_1b306'
work_dir = 'work_dirs/local-basic/230915_1428_PatchMask_ricky_ratio=321_1b306'
git_rev = ''
