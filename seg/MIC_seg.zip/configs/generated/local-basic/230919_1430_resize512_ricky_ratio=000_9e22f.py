_base_ = '../../mic/Med_semi_supervised.py'
name = '230919_1430_resize512_ricky_ratio=000_9e22f'
work_dir = 'work_dirs/local-basic/230919_1430_resize512_ricky_ratio=000_9e22f'
git_rev = ''
