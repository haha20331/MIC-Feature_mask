_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230819_0921_CleanData_WithoutFD_tua=0.92_60dac'
work_dir = 'work_dirs/local-basic/230819_0921_CleanData_WithoutFD_tua=0.92_60dac'
git_rev = ''
