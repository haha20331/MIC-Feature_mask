_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230828_1621_test_a3c45'
work_dir = 'work_dirs/local-basic/230828_1621_test_a3c45'
git_rev = ''
