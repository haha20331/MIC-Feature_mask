_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230825_1454_test_bcabc'
work_dir = 'work_dirs/local-basic/230825_1454_test_bcabc'
git_rev = ''
