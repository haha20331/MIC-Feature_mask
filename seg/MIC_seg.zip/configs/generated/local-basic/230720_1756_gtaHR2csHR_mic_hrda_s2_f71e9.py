_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230720_1756_gtaHR2csHR_mic_hrda_s2_f71e9'
work_dir = 'work_dirs/local-basic/230720_1756_gtaHR2csHR_mic_hrda_s2_f71e9'
git_rev = ''
