_base_ = '../../mic/Med_semi_supervised.py'
name = '230915_1534_PatchMask_ricky_ratio=5400_29f5e'
work_dir = 'work_dirs/local-basic/230915_1534_PatchMask_ricky_ratio=5400_29f5e'
git_rev = ''
