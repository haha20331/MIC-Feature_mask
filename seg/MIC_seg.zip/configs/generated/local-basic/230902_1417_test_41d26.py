_base_ = '../../mic/Med_semi_supervised_test.py'
name = '230902_1417_test_41d26'
work_dir = 'work_dirs/local-basic/230902_1417_test_41d26'
git_rev = ''
