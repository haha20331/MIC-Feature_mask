_base_ = '../../mic/Med_semi_supervised.py'
name = '230911_1428_test_14a28'
work_dir = 'work_dirs/local-basic/230911_1428_test_14a28'
git_rev = ''
