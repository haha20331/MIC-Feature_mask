_base_ = '../../mic/Med_semi_supervised.py'
name = '230912_2004_test_edc61'
work_dir = 'work_dirs/local-basic/230912_2004_test_edc61'
git_rev = ''
