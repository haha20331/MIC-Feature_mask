_base_ = '../../mic/Med_semi_supervised.py'
name = '230907_1321_test_c5358'
work_dir = 'work_dirs/local-basic/230907_1321_test_c5358'
git_rev = ''
