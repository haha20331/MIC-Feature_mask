_base_ = '../../mic/Med_semi_supervised.py'
name = '230915_1424_PatchMask_ricky_ratio=321_f10ee'
work_dir = 'work_dirs/local-basic/230915_1424_PatchMask_ricky_ratio=321_f10ee'
git_rev = ''
