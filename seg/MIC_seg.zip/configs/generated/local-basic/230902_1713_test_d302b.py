_base_ = '../../mic/Med_semi_supervised.py'
name = '230902_1713_test_d302b'
work_dir = 'work_dirs/local-basic/230902_1713_test_d302b'
git_rev = ''
