_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230728_0100_AllData_WithoutFD_WithoutUnlabele3_2fda8'
work_dir = 'work_dirs/local-basic/230728_0100_AllData_WithoutFD_WithoutUnlabele3_2fda8'
git_rev = ''
