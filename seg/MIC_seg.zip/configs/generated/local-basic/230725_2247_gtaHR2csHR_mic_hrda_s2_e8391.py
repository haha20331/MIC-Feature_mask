_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230725_2247_gtaHR2csHR_mic_hrda_s2_e8391'
work_dir = 'work_dirs/local-basic/230725_2247_gtaHR2csHR_mic_hrda_s2_e8391'
git_rev = ''
