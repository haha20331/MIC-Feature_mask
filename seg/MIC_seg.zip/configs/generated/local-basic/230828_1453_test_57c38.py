_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230828_1453_test_57c38'
work_dir = 'work_dirs/local-basic/230828_1453_test_57c38'
git_rev = ''
