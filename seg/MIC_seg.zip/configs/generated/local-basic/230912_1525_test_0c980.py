_base_ = '../../mic/Med_semi_supervised.py'
name = '230912_1525_test_0c980'
work_dir = 'work_dirs/local-basic/230912_1525_test_0c980'
git_rev = ''
