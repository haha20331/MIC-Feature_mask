_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230703_1539_gtaHR2csHR_mic_hrda_s2_519ed'
work_dir = 'work_dirs/local-basic/230703_1539_gtaHR2csHR_mic_hrda_s2_519ed'
git_rev = ''
