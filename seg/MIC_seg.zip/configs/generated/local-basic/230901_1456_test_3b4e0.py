_base_ = '../../mic/Med_semi_supervised.py'
name = '230901_1456_test_3b4e0'
work_dir = 'work_dirs/local-basic/230901_1456_test_3b4e0'
git_rev = ''
