_base_ = '../../mic/Med_semi_supervised.py'
name = '230918_1814_resize1440_crop256_31474'
work_dir = 'work_dirs/local-basic/230918_1814_resize1440_crop256_31474'
git_rev = ''
