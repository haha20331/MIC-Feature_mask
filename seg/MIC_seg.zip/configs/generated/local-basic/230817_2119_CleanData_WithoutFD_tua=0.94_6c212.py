_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230817_2119_CleanData_WithoutFD_tua=0.94_6c212'
work_dir = 'work_dirs/local-basic/230817_2119_CleanData_WithoutFD_tua=0.94_6c212'
git_rev = ''
