_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230825_1450_test_71938'
work_dir = 'work_dirs/local-basic/230825_1450_test_71938'
git_rev = ''
