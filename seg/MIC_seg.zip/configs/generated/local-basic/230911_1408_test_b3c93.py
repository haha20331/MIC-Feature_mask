_base_ = '../../mic/Med_semi_supervised.py'
name = '230911_1408_test_b3c93'
work_dir = 'work_dirs/local-basic/230911_1408_test_b3c93'
git_rev = ''
