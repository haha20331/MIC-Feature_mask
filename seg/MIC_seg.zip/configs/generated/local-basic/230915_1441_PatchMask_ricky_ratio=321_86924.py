_base_ = '../../mic/Med_semi_supervised.py'
name = '230915_1441_PatchMask_ricky_ratio=321_86924'
work_dir = 'work_dirs/local-basic/230915_1441_PatchMask_ricky_ratio=321_86924'
git_rev = ''
