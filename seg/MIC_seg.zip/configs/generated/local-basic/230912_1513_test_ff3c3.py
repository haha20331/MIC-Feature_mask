_base_ = '../../mic/Med_semi_supervised.py'
name = '230912_1513_test_ff3c3'
work_dir = 'work_dirs/local-basic/230912_1513_test_ff3c3'
git_rev = ''
