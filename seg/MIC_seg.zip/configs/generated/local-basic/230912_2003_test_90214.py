_base_ = '../../mic/Med_semi_supervised.py'
name = '230912_2003_test_90214'
work_dir = 'work_dirs/local-basic/230912_2003_test_90214'
git_rev = ''
