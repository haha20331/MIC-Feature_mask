_base_ = '../../mic/Med_semi_supervised.py'
name = '230911_1431_test_55f53'
work_dir = 'work_dirs/local-basic/230911_1431_test_55f53'
git_rev = ''
