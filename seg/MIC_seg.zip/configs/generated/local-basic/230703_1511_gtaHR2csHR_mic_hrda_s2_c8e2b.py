_base_ = '../../mic/gtaHR2csHR_mic_hrda.py'
name = '230703_1511_gtaHR2csHR_mic_hrda_s2_c8e2b'
work_dir = 'work_dirs/local-basic/230703_1511_gtaHR2csHR_mic_hrda_s2_c8e2b'
git_rev = ''
